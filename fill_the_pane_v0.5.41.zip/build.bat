@echo off
echo Building...
python -m PyInstaller fill_the_pane.spec > build_log.txt 2>&1
if %ERRORLEVEL% == 0 (
    echo Build successful.
    for /f "tokens=2 delims='" %%n in ('findstr /c:"name=" fill_the_pane.spec') do start "" "dist\%%n.exe"
) else (
    echo Build failed.
    notepad build_log.txt
)